/**
 * AuthCallbackPage — Güvenli OAuth Callback
 *
 * S-03: session_id yalnızca URL query parametresinden (?session_id=...) alınır.
 *       URL hash'inden (#session_id=...) asla okunmaz → session fixation engellenir.
 *       Geçersiz/eksik session_id durumunda kullanıcı /giris'e yönlendirilir.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';

export default function AuthCallbackPage() {
  const { handleOAuthCallback } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('verifying'); // 'verifying' | 'error'

  useEffect(() => {
    const process = async () => {
      // S-03: yalnızca query param — hash'e bakılmaz
      const sessionId = searchParams.get('session_id');

      if (!sessionId) {
        setStatus('error');
        setTimeout(() => navigate('/giris', { replace: true }), 2000);
        return;
      }

      try {
        await handleOAuthCallback(sessionId);
        // URL'den session_id'yi temizle (history'e gizli parametre bırakma)
        window.history.replaceState(null, '', '/');
        navigate('/', { replace: true });
      } catch {
        setStatus('error');
        setTimeout(() => navigate('/giris', { replace: true }), 2000);
      }
    };

    process();
  }, [handleOAuthCallback, navigate, searchParams]);

  const messages = {
    verifying: 'Kimlik doğrulanıyor...',
    error: 'Giriş başarısız. Yönlendiriliyorsunuz...',
  };

  return (
    <div className="min-h-screen bg-[#F8F5F0] flex items-center justify-center" role="status">
      <div className="text-center">
        {status === 'verifying' && <LoadingSpinner size="lg" className="mx-auto mb-5" />}
        <p className="text-[13px] text-[#4A4A4A]">{messages[status]}</p>
      </div>
    </div>
  );
}
