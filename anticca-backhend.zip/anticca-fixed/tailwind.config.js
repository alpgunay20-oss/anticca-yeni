/**
 * tailwind.config.js — Design Token Sistemi
 *
 * 5.1: 200+ inline renk referansı token'lara taşındı.
 * Tema değişikliği artık tek yerden yönetilir.
 */
/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      // ── Anticca Design Tokens ──────────────────────────────────────
      colors: {
        // Marka renkleri
        brand: {
          primary:  '#8B7355',
          light:    '#A6926E',
          dark:     '#6B5A40',
          '10':     'rgba(139,115,85,0.10)',
          '40':     'rgba(139,115,85,0.40)',
        },
        // Yüzey renkleri
        surface: {
          bg:     '#FAFAF7',
          bgAlt:  '#F8F5F0',
          card:   '#FFFFFF',
          muted:  '#F5F1EB',
        },
        // Metin renkleri
        text: {
          primary:   '#2C2C2C',
          secondary: '#4A4A4A',
          muted:     '#7A7A7A',
        },
        // Kenarlık
        border: {
          DEFAULT: '#E0D8CC',
        },

        // ── Radix UI / shadcn uyumlu token'lar (mevcut UI bileşenleri için) ──
        background:  'hsl(var(--background))',
        foreground:  'hsl(var(--foreground))',
        card: {
          DEFAULT:    'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        popover: {
          DEFAULT:    'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        primary: {
          DEFAULT:    'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT:    'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        muted: {
          DEFAULT:    'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT:    'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        destructive: {
          DEFAULT:    'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        input:  'hsl(var(--input))',
        ring:   'hsl(var(--ring))',
        chart: {
          '1': 'hsl(var(--chart-1))',
          '2': 'hsl(var(--chart-2))',
          '3': 'hsl(var(--chart-3))',
          '4': 'hsl(var(--chart-4))',
          '5': 'hsl(var(--chart-5))',
        },
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      keyframes: {
        'accordion-down': { from: { height: '0' }, to: { height: 'var(--radix-accordion-content-height)' } },
        'accordion-up':   { from: { height: 'var(--radix-accordion-content-height)' }, to: { height: '0' } },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up':   'accordion-up 0.2s ease-out',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
