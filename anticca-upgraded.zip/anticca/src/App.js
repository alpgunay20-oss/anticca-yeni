import React, { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { CartProvider } from "./contexts/CartContext";
import { Toaster } from "./components/ui/sonner";

import HomePage from "./pages/HomePage";
import AuctionsPage from "./pages/AuctionsPage";
import DirectSalesPage from "./pages/DirectSalesPage";
import ProductPage from "./pages/ProductPage";
import StoresPage from "./pages/StoresPage";
import StoreProfilePage from "./pages/StoreProfilePage";
import ArticlesPage from "./pages/ArticlesPage";
import ArticleDetailPage from "./pages/ArticleDetailPage";
import AboutPage from "./pages/AboutPage";
import FAQPage from "./pages/FAQPage";
import PrivacyPage from "./pages/PrivacyPage";
import CommissionPage from "./pages/CommissionPage";
import AuthPage, { AuthCallback } from "./pages/AuthPage";
import DashboardPage from "./pages/DashboardPage";
import CartPage from "./pages/CartPage";
import CheckoutPage, { CheckoutSuccess } from "./pages/CheckoutPage";
import AdminPage from "./pages/AdminPage";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8F5F0] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#8B7355] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) return <Navigate to="/giris" replace />;
  return children;
}

function AppRouter() {
  const location = useLocation();

  if (location.hash?.includes('session_id=')) {
    return <AuthCallback />;
  }

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/muzayedeler" element={<AuctionsPage />} />
      <Route path="/direkt-satis" element={<DirectSalesPage />} />
      <Route path="/urun/:id" element={<ProductPage />} />
      <Route path="/magazalar" element={<StoresPage />} />
      <Route path="/magaza/:id" element={<StoreProfilePage />} />
      <Route path="/makaleler" element={<ArticlesPage />} />
      <Route path="/makale/:id" element={<ArticleDetailPage />} />
      <Route path="/hakkimizda" element={<AboutPage />} />
      <Route path="/sss" element={<FAQPage />} />
      <Route path="/gizlilik" element={<PrivacyPage />} />
      <Route path="/komisyon-politikasi" element={<CommissionPage />} />
      <Route path="/giris" element={<AuthPage />} />
      <Route path="/auth/callback" element={<AuthCallback />} />
      <Route path="/hesabim" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
      <Route path="/sepet" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
      <Route path="/odeme" element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
      <Route path="/checkout/success" element={<ProtectedRoute><CheckoutSuccess /></ProtectedRoute>} />
      <Route path="/admin" element={<ProtectedRoute><AdminPage /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <LanguageProvider>
          <CartProvider>
            <ScrollToTop />
            <AppRouter />
            <Toaster
              position="top-right"
              toastOptions={{
                style: {
                  background: '#FAFAF7',
                  border: '1px solid #E0D8CC',
                  color: '#2C2C2C',
                  fontFamily: 'DM Sans, sans-serif',
                  fontSize: '13px'
                }
              }}
            />
          </CartProvider>
        </LanguageProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
