import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const { user, api } = useAuth();

  const refreshCart = useCallback(async () => {
    if (!user) { setItems([]); setCartCount(0); return; }
    try {
      const res = await api().get('/api/cart');
      setItems(res.data.items || []);
      setCartCount((res.data.items || []).length);
    } catch { setItems([]); setCartCount(0); }
  }, [user, api]);

  useEffect(() => { refreshCart(); }, [refreshCart]);

  const addToCart = async (productId) => {
    await api().post('/api/cart', { product_id: productId, quantity: 1 });
    await refreshCart();
  };

  const removeFromCart = async (productId) => {
    await api().delete(`/api/cart/${productId}`);
    await refreshCart();
  };

  const getTotal = () => {
    return items.reduce((sum, item) => sum + (item.product?.price || 0) * (item.quantity || 1), 0);
  };

  return (
    <CartContext.Provider value={{ items, cartCount, refreshCart, addToCart, removeFromCart, getTotal }}>
      {children}
    </CartContext.Provider>
  );
};
