import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('anticca_token'));
  const [loading, setLoading] = useState(true);

  const api = useCallback(() => {
    return axios.create({
      baseURL: BACKEND_URL,
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      withCredentials: true
    });
  }, [token]);

  useEffect(() => {
    const checkAuth = async () => {
      if (!token) { setLoading(false); return; }
      try {
        const res = await api().get('/api/auth/me');
        setUser(res.data);
      } catch {
        localStorage.removeItem('anticca_token');
        setToken(null);
        setUser(null);
      }
      setLoading(false);
    };
    checkAuth();
  }, [token, api]);

  const login = async (email, password) => {
    const res = await axios.post(`${BACKEND_URL}/api/auth/login`, { email, password });
    const { token: newToken, user: userData } = res.data;
    localStorage.setItem('anticca_token', newToken);
    setToken(newToken);
    setUser(userData);
    return userData;
  };

  const register = async (name, email, password, phone) => {
    const res = await axios.post(`${BACKEND_URL}/api/auth/register`, { name, email, password, phone });
    const { token: newToken, user: userData } = res.data;
    localStorage.setItem('anticca_token', newToken);
    setToken(newToken);
    setUser(userData);
    return userData;
  };

  const handleOAuthCallback = async (sessionId) => {
    const res = await axios.get(`${BACKEND_URL}/api/auth/session?session_id=${sessionId}`, { withCredentials: true });
    const { token: newToken, user: userData } = res.data;
    localStorage.setItem('anticca_token', newToken);
    setToken(newToken);
    setUser(userData);
    return userData;
  };

  const logout = async () => {
    try { await api().post('/api/auth/logout'); } catch {}
    localStorage.removeItem('anticca_token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout, handleOAuthCallback, api }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}

export default AuthContext;
