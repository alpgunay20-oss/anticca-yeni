import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { BarChart3, Package, Users, ShoppingCart, Store, FileText, CheckCircle, X } from 'lucide-react';

export default function AdminPage() {
  const { t, tObj } = useLanguage();
  const { api } = useAuth();
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [statsRes, productsRes, usersRes, ordersRes] = await Promise.all([
          api().get('/api/admin/stats'),
          api().get('/api/products?limit=100'),
          api().get('/api/admin/users'),
          api().get('/api/admin/orders'),
        ]);
        setStats(statsRes.data);
        setProducts(productsRes.data.products || []);
        setUsers(usersRes.data.users || []);
        setOrders(ordersRes.data.orders || []);
      } catch { }
      setLoading(false);
    };
    load();
  }, [api]);

  const tabs = [
    { key: 'overview', label: 'Genel Bakis', icon: <BarChart3 className="w-4 h-4" /> },
    { key: 'products', label: 'Urunler', icon: <Package className="w-4 h-4" /> },
    { key: 'orders', label: 'Siparisler', icon: <ShoppingCart className="w-4 h-4" /> },
    { key: 'users', label: 'Kullanicilar', icon: <Users className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="font-serif text-3xl text-[#2C2C2C] mb-8">{t('nav.admin')}</h1>

        <div className="flex gap-2 mb-8 overflow-x-auto">
          {tabs.map(tb => (
            <button
              key={tb.key}
              onClick={() => setTab(tb.key)}
              className={`flex items-center gap-2 px-4 py-2 text-sm whitespace-nowrap transition-colors ${tab === tb.key ? 'bg-[#8B7355] text-white' : 'border border-[#E0D8CC] text-[#4A4A4A] hover:border-[#8B7355]'}`}
            >
              {tb.icon} {tb.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><div className="w-8 h-8 border-2 border-[#8B7355] border-t-transparent rounded-full animate-spin" /></div>
        ) : (
          <>
            {tab === 'overview' && stats && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { label: 'Urunler', value: stats.total_products, icon: <Package className="w-5 h-5" /> },
                  { label: 'Muzayedeler', value: stats.active_auctions, icon: <BarChart3 className="w-5 h-5" /> },
                  { label: 'Kullanicilar', value: stats.total_users, icon: <Users className="w-5 h-5" /> },
                  { label: 'Siparisler', value: stats.total_orders, icon: <ShoppingCart className="w-5 h-5" /> },
                  { label: 'Magazalar', value: stats.total_stores, icon: <Store className="w-5 h-5" /> },
                  { label: 'Gelir', value: `$${stats.total_revenue?.toLocaleString() || 0}`, icon: <FileText className="w-5 h-5" /> },
                ].map((s, i) => (
                  <div key={i} className="bg-white border border-[#E0D8CC] p-4">
                    <div className="text-[#8B7355] mb-2">{s.icon}</div>
                    <p className="font-mono-data text-2xl text-[#2C2C2C]">{s.value}</p>
                    <p className="text-[10px] uppercase tracking-wider text-[#7A7A7A] mt-1">{s.label}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === 'products' && (
              <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#F5F1EB] text-left">
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Urun</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Kategori</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Tur</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Fiyat</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Durum</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map(p => (
                      <tr key={p.product_id} className="border-t border-[#E0D8CC]">
                        <td className="py-3 px-4 text-sm text-[#2C2C2C]">{tObj(p.title)}</td>
                        <td className="py-3 px-4 text-xs text-[#7A7A7A]">{p.category}</td>
                        <td className="py-3 px-4 text-xs">{p.is_auction ? <span className="text-[#8B7355]">Muzayede</span> : 'Direkt'}</td>
                        <td className="py-3 px-4 font-mono-data text-sm">${(p.is_auction ? p.current_bid : p.price)?.toLocaleString()}</td>
                        <td className="py-3 px-4"><span className="text-[10px] uppercase tracking-wider bg-[#F5F1EB] text-[#8B7355] px-2 py-0.5">{p.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {tab === 'orders' && (
              <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#F5F1EB] text-left">
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Siparis</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Tutar</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Odeme</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Durum</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Tarih</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(o => (
                      <tr key={o.order_id} className="border-t border-[#E0D8CC]">
                        <td className="py-3 px-4 font-mono-data text-xs text-[#4A4A4A]">{o.order_id}</td>
                        <td className="py-3 px-4 font-mono-data text-sm">${o.total?.toLocaleString()}</td>
                        <td className="py-3 px-4 text-xs">{o.payment_method}</td>
                        <td className="py-3 px-4"><span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 ${o.status === 'confirmed' ? 'bg-green-50 text-green-700' : 'bg-[#F5F1EB] text-[#8B7355]'}`}>{o.status}</span></td>
                        <td className="py-3 px-4 text-xs text-[#7A7A7A]">{new Date(o.created_at).toLocaleDateString('tr-TR')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {tab === 'users' && (
              <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#F5F1EB] text-left">
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Ad</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">E-posta</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Rol</th>
                      <th className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">Kayit Tarihi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.user_id} className="border-t border-[#E0D8CC]">
                        <td className="py-3 px-4 text-sm text-[#2C2C2C]">{u.name}</td>
                        <td className="py-3 px-4 text-sm text-[#4A4A4A]">{u.email}</td>
                        <td className="py-3 px-4"><span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 ${u.role === 'admin' ? 'bg-[#8B7355]/10 text-[#8B7355]' : 'bg-[#F5F1EB] text-[#7A7A7A]'}`}>{u.role}</span></td>
                        <td className="py-3 px-4 text-xs text-[#7A7A7A]">{u.created_at ? new Date(u.created_at).toLocaleDateString('tr-TR') : '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}
